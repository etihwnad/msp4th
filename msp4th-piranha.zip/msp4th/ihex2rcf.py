#!/usr/bin/env python

import sys
import optparse

from intelhex import IntelHex

parser = optparse.OptionParser()

parser.add_option('-s', '--start', dest='start',
        action='store', type='int', help='Starting hex address of RCF')

parser.add_option('-l', '--length', dest='length',
        action='store', type='int', help='Length of RCF in words')

parser.add_option('-w', '--width', dest='width',
        action='store', type='int', help='Word size in bits')

parser.add_option('-d', '--default', dest='default',
        action='store', type='int', help='Default word for unspecified addresses')

(opt, args) = parser.parse_args()



def binword(w, width=16):
    """Return a width-length, left-zero-padded bit string binary representation
    of the integer w."""
    b = bin(w)
    b = b.lstrip('0b')
    return ('0' * (width - len(b))) + b


nbytes = (opt.width // 8) * opt.length
bytewidth = opt.width // 8

h = IntelHex(args[0])

#padding is *per byte* here, we need complete words and are specifying the
#default *word*.  This lets us detect the missing values
h.padding = None


# dump all the ROM addresses
for addr in range(opt.start, (opt.start + opt.length), bytewidth):
    word = 0
    bites = [h[a] is None for a in range(addr, addr+bytewidth)]

    if all(bites):
        word = opt.default
    elif any(bites):
        raise Exception('Bytes must be specified for a complete word')
    else:
        for b in range(bytewidth):
            word += h[addr + b] << (8*b)

    print binword(word)

