#include <iomacros.h>
#define PC_AFTER_RESET_ 0x3000
sfrw(PC_AFTER_RESET,PC_AFTER_RESET_);
#define CRCDI_ 0x0000
sfrw(CRCDI,CRCDI_);
#define CRCDI_L_ 0x0000
sfrw(CRCDI_L,CRCDI_L_);
#define CRCDI_H_ 0x0001
sfrw(CRCDI_H,CRCDI_H_);
#define CRCDIRB_ 0x0002
sfrw(CRCDIRB,CRCDIRB_);
#define CRCDIRB_L_ 0x0002
sfrw(CRCDIRB_L,CRCDIRB_L_);
#define CRCDIRB_H_ 0x0002
sfrw(CRCDIRB_H,CRCDIRB_H_);
#define CRCINIRES_ 0x0004
sfrw(CRCINIRES,CRCINIRES_);
#define CRCINIRES_L_ 0x0004
sfrw(CRCINIRES_L,CRCINIRES_L_);
#define CRCINIRES_H_ 0x0005
sfrw(CRCINIRES_H,CRCINIRES_H_);
#define CRCRESR_ 0x0006
sfrw(CRCRESR,CRCRESR_);
#define CRCRESR_L_ 0x0006
sfrw(CRCRESR_L,CRCRESR_L_);
#define CRCRESR_H_ 0x0007
sfrw(CRCRESR_H,CRCRESR_H_);
#define MPY_ 0x0130
sfrw(MPY,MPY_);
#define MPYS_ 0x0132
sfrw(MPYS,MPYS_);
#define MAC_ 0x0134
sfrw(MAC,MAC_);
#define MACS_ 0x0136
sfrw(MACS,MACS_);
#define OP2_ 0x0138
sfrw(OP2,OP2_);
#define RESLO_ 0x013a
sfrw(RESLO,RESLO_);
#define RESHI_ 0x013c
sfrw(RESHI,RESHI_);
#define SUMEXT_ 0x013e
sfrw(SUMEXT,SUMEXT_);
#define AES_CR_ 0x0400
sfrw(AES_CR,AES_CR_);
#define AES_SR_ 0x0402
sfrw(AES_SR,AES_SR_);
#define AES_STATE_ 0x0410
sfrw(AES_STATE,AES_STATE_);
#define AES_STATE_SIZE_ 0x0010
sfrw(AES_STATE_SIZE,AES_STATE_SIZE_);
#define AES_KEY_ 0x0700
sfrw(AES_KEY,AES_KEY_);
#define AES_KEY_SIZE_ 0x0020
sfrw(AES_KEY_SIZE,AES_KEY_SIZE_);
#define AES_EXPKEY_ 0x0720
sfrw(AES_EXPKEY,AES_EXPKEY_);
#define AES_EXPKEY_SIZE_ 0x00e0
sfrw(AES_EXPKEY_SIZE,AES_EXPKEY_SIZE_);
#define PADSR_ 0x1a00
sfrw(PADSR,PADSR_);
#define PBDSR_ 0x1a02
sfrw(PBDSR,PBDSR_);
#define PAOEN_ 0x1a04
sfrw(PAOEN,PAOEN_);
#define PBOEN_ 0x1a06
sfrw(PBOEN,PBOEN_);
#define PAOUT_ 0x1a08
sfrw(PAOUT,PAOUT_);
#define PBOUT_ 0x1a0a
sfrw(PBOUT,PBOUT_);
#define PAPER_ 0x1a0c
sfrw(PAPER,PAPER_);
#define PBPER_ 0x1a0e
sfrw(PBPER,PBPER_);
#define PAIER_ 0x1a10
sfrw(PAIER,PAIER_);
#define PBIER_ 0x1a12
sfrw(PBIER,PBIER_);
#define PAIMR_ 0x1a14
sfrw(PAIMR,PAIMR_);
#define PBIMR_ 0x1a16
sfrw(PBIMR,PBIMR_);
#define PAPUE_ 0x1a18
sfrw(PAPUE,PAPUE_);
#define PBPUE_ 0x1a1a
sfrw(PBPUE,PBPUE_);
#define PBTSD_ 0x1a1c
sfrw(PBTSD,PBTSD_);
#define PBPSR_ 0x1a1e
sfrw(PBPSR,PBPSR_);
#define PAOCEN_ 0x1a20
sfrw(PAOCEN,PAOCEN_);
#define PBOCEN_ 0x1a22
sfrw(PBOCEN,PBOCEN_);
#define TMR0_CR_ 0x1c00
sfrw(TMR0_CR,TMR0_CR_);
#define TMR0_SR_ 0x1c02
sfrw(TMR0_SR,TMR0_SR_);
#define TMR0_CNT_ 0x1c04
sfrw(TMR0_CNT,TMR0_CNT_);
#define TMR0_RA_ 0x1c06
sfrw(TMR0_RA,TMR0_RA_);
#define TMR0_RB_ 0x1c08
sfrw(TMR0_RB,TMR0_RB_);
#define TMR0_RC_ 0x1c0a
sfrw(TMR0_RC,TMR0_RC_);
#define TMR0_CAP0_ 0x1c0c
sfrw(TMR0_CAP0,TMR0_CAP0_);
#define TMR0_CAP1_ 0x1c0e
sfrw(TMR0_CAP1,TMR0_CAP1_);
#define TMR1_CR_ 0x1c10
sfrw(TMR1_CR,TMR1_CR_);
#define TMR1_SR_ 0x1c12
sfrw(TMR1_SR,TMR1_SR_);
#define TMR1_CNT_ 0x1c14
sfrw(TMR1_CNT,TMR1_CNT_);
#define TMR1_RA_ 0x1c16
sfrw(TMR1_RA,TMR1_RA_);
#define TMR1_RB_ 0x1c18
sfrw(TMR1_RB,TMR1_RB_);
#define TMR1_RC_ 0x1c1a
sfrw(TMR1_RC,TMR1_RC_);
#define TMR1_CAP0_ 0x1c1c
sfrw(TMR1_CAP0,TMR1_CAP0_);
#define TMR1_CAP1_ 0x1c1e
sfrw(TMR1_CAP1,TMR1_CAP1_);
#define TMR2_CR_ 0x1e00
sfrw(TMR2_CR,TMR2_CR_);
#define TMR2_SR_ 0x1e02
sfrw(TMR2_SR,TMR2_SR_);
#define TMR2_CNT_ 0x1e04
sfrw(TMR2_CNT,TMR2_CNT_);
#define TMR2_RA_ 0x1e06
sfrw(TMR2_RA,TMR2_RA_);
#define TMR2_RB_ 0x1e08
sfrw(TMR2_RB,TMR2_RB_);
#define TMR2_RC_ 0x1e0a
sfrw(TMR2_RC,TMR2_RC_);
#define TMR2_CAP0_ 0x1e0c
sfrw(TMR2_CAP0,TMR2_CAP0_);
#define TMR2_CAP1_ 0x1e0e
sfrw(TMR2_CAP1,TMR2_CAP1_);
#define TMR3_CR_ 0x1e10
sfrw(TMR3_CR,TMR3_CR_);
#define TMR3_SR_ 0x1e12
sfrw(TMR3_SR,TMR3_SR_);
#define TMR3_CNT_ 0x1e14
sfrw(TMR3_CNT,TMR3_CNT_);
#define TMR3_RA_ 0x1e16
sfrw(TMR3_RA,TMR3_RA_);
#define TMR3_RB_ 0x1e18
sfrw(TMR3_RB,TMR3_RB_);
#define TMR3_RC_ 0x1e1a
sfrw(TMR3_RC,TMR3_RC_);
#define TMR3_CAP0_ 0x1e1c
sfrw(TMR3_CAP0,TMR3_CAP0_);
#define TMR3_CAP1_ 0x1e1e
sfrw(TMR3_CAP1,TMR3_CAP1_);
#define SPI0_CR_ 0x2000
sfrw(SPI0_CR,SPI0_CR_);
#define SPI0_RDR_ 0x2002
sfrw(SPI0_RDR,SPI0_RDR_);
#define SPI0_TDR_ 0x2004
sfrw(SPI0_TDR,SPI0_TDR_);
#define SPI0_SR_ 0x2006
sfrw(SPI0_SR,SPI0_SR_);
#define SPI1_CR_ 0x2008
sfrw(SPI1_CR,SPI1_CR_);
#define SPI1_RDR_ 0x200a
sfrw(SPI1_RDR,SPI1_RDR_);
#define SPI1_TDR_ 0x200c
sfrw(SPI1_TDR,SPI1_TDR_);
#define SPI1_SR_ 0x200e
sfrw(SPI1_SR,SPI1_SR_);
#define UART0_CR_ 0x2200
sfrw(UART0_CR,UART0_CR_);
#define UART0_BCR_ 0x2202
sfrw(UART0_BCR,UART0_BCR_);
#define UART0_SR_ 0x2204
sfrw(UART0_SR,UART0_SR_);
#define UART0_RDR_ 0x2206
sfrw(UART0_RDR,UART0_RDR_);
#define UART0_TDR_ 0x2208
sfrw(UART0_TDR,UART0_TDR_);
#define UART1_CR_ 0x2210
sfrw(UART1_CR,UART1_CR_);
#define UART1_BCR_ 0x2212
sfrw(UART1_BCR,UART1_BCR_);
#define UART1_SR_ 0x2214
sfrw(UART1_SR,UART1_SR_);
#define UART1_RDR_ 0x2216
sfrw(UART1_RDR,UART1_RDR_);
#define UART1_TDR_ 0x2218
sfrw(UART1_TDR,UART1_TDR_);
#define ADC_CR_ 0x2400
sfrw(ADC_CR,ADC_CR_);
#define GPIN0_ 0x2402
sfrw(GPIN0,GPIN0_);
#define GPIN1_ 0x2404
sfrw(GPIN1,GPIN1_);
#define GPOUT0_ 0x2406
sfrw(GPOUT0,GPOUT0_);
#define GPOUT1_ 0x2408
sfrw(GPOUT1,GPOUT1_);
#define GPOUT2_ 0x240a
sfrw(GPOUT2,GPOUT2_);
#define GPOUT3_ 0x240c
sfrw(GPOUT3,GPOUT3_);
#define I2CM_CR_ 0x2a00
sfrw(I2CM_CR,I2CM_CR_);
#define I2CM_TCFG_ 0x2a02
sfrw(I2CM_TCFG,I2CM_TCFG_);
#define I2CM_SR_ 0x2a04
sfrw(I2CM_SR,I2CM_SR_);
#define I2CM_WCR_ 0x2a06
sfrw(I2CM_WCR,I2CM_WCR_);
#define I2CM_TDR_ST_ 0x2a08
sfrw(I2CM_TDR_ST,I2CM_TDR_ST_);
#define I2CM_TDR_ 0x2a0a
sfrw(I2CM_TDR,I2CM_TDR_);
#define I2CM_TDR_SP_ 0x2a0c
sfrw(I2CM_TDR_SP,I2CM_TDR_SP_);
#define I2CM_RDR_ 0x2a0e
sfrw(I2CM_RDR,I2CM_RDR_);
#define I2CS_CR_ 0x2a10
sfrw(I2CS_CR,I2CS_CR_);
#define I2CS_SR_ 0x2a12
sfrw(I2CS_SR,I2CS_SR_);
#define I2CS_TDR_ 0x2a14
sfrw(I2CS_TDR,I2CS_TDR_);
#define I2CS_RDR_ 0x2a16
sfrw(I2CS_RDR,I2CS_RDR_);
#define ROMStart_ 0x3000
sfrw(ROMStart,ROMStart_);
#define ROMSize_ 0x0800
sfrw(ROMSize,ROMSize_);
#define RAMStart_ 0x4000
sfrw(RAMStart,RAMStart_);
#define RAMSize_ 0xc000
sfrw(RAMSize,RAMSize_);
