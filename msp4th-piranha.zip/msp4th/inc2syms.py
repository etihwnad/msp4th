#!/usr/bin/env python

import sys

VERBOSE = False

if len(sys.argv) < 2 or sys.argv[1] == '-h':
    print>>sys.stderr, 'Usage: %s syms.inc [file.asm]'
    sys.exit(1)

incfile = open(sys.argv[1])

if len(sys.argv) == 2:
    asmfile = sys.stdin
else:
    asmfile = open(sys.argv[2])


syms = {}
addrs = {}
print 'Symbol Table:'
for line in incfile:
    if line.startswith('.equ'):
        sp = line.strip().split()
        sym = sp[1][:-1]
        value = sp[2]
        syms[sym] = value
        addrs[syms[sym]] = sym
        print '  %s: %s' % (sym, syms[sym])


lines = asmfile.readlines()

newlines = []
for line in lines:
    oldline = line
    replaced = False
    for addr in addrs.iterkeys():
        if addr in line:
            line = line.replace(addr, addrs[addr])
            if VERBOSE:
                if replaced:
                    print>>sys.stderr, '*** double replacement !!!'
                print>>sys.stderr, 'old:', oldline.rstrip()
                print>>sys.stderr, 'new:', line.rstrip()
            replaced = True

    newlines.append(line)

print ''.join(newlines)
#sys.stdout.write(''.join(newlines))
