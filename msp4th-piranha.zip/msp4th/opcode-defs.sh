#!/bin/bash

grep '//.*(.*--.*)' msp4th.c
